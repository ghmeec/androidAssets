package me.ghmeec.root.arrayadapter;

public class Words {
    String englishWorld;
    String nativeWorld;
    public Words(String englishWord,String nativeWorld){
        this.englishWorld=englishWord;
        this.nativeWorld=nativeWorld;
    }

    public String getEnglishWorld() {
        return englishWorld;
    }

    public String getNativeWorld() {
        return nativeWorld;
    }
}
