package me.ghmeec.root.arrayadapter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.GridLayout;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayList<Words> words=new ArrayList<Words>();
        words.add(new  Words("one","moja"));
        words.add(new Words("two","mbili"));
        words.add(new Words("theree","tatu"));
        words.add(new Words("four","nne"));
        words.add(new Words("five","tano"));
        words.add(new Words("six","sita"));
        words.add(new Words("seven","saba"));
        words.add(new Words("eight","nane"));
        words.add(new Words("nine","tisa"));
        words.add(new Words("ten","kumi"));

      ListView parent=(ListView) findViewById(R.id.parent);

        WordsAdapter itemsAdapter=new WordsAdapter(this,words);
        parent.setAdapter(itemsAdapter);





    }
}
